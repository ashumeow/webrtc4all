﻿/*
* Copyright (C) 2012 Doubango Telecom <http://www.doubango.org>
* License: BSD
* This file is part of Open Source sipML5 solution <http://www.sipml5.org>
*/
var __tmedia_defaults_e_media_type = tmedia_type_e.AUDIO_VIDEO;

function tmedia_defaults_get_media_type() {
    return __tmedia_defaults_e_media_type;
}